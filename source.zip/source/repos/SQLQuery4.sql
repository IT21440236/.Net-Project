﻿select * From dbo.Customer

delete From dbo.Customer