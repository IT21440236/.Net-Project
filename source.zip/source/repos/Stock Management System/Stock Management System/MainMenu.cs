﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stock_Management_System
{
    public partial class MainMenu : Form
    {
        public MainMenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            Login ss = new Login();
            ss.Show();
        }

        private void MainMenu_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();

            Employee ss = new Employee();
            ss.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();

            Customer ss = new Customer();
            ss.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            Logout ss = new Logout();
            ss.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();

            Managercs ss = new Managercs();
            ss.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();

            Supplier ss = new Supplier();
            ss.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();

            Customerorder ss = new Customerorder();
            ss.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();

            StockDetails ss = new StockDetails();
            ss.Show();
        }
    }

    
    
}
