﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Stock_Management_System
{
    public partial class Customerorder : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\YERAN\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
        public Customerorder()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            MainMenu ss = new MainMenu();
            ss.Show();
        }

        private void Customerorder_Load(object sender, EventArgs e)
        {
            
        }

        public void disp()
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from Customero";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into Customero values('" + textBox1.Text + "','" + textBox3.Text + "','" + textBox2.Text + "','" + textBox4.Text + "')";
            con.Open();
            cmd.ExecuteNonQuery();
            disp();
            MessageBox.Show("Customer Order Added Successfully  ");
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (e == null)
            {
                throw new ArgumentNullException(nameof(e));
            }

            try
            {
                string Item = textBox1.Text;
                string query_delete = "delete from [Customero] where Item  ='" + Item + "'";
                SqlCommand cmd = new SqlCommand(query_delete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                disp();
                MessageBox.Show("Record Deleted Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error While Deleting !" + ex);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
